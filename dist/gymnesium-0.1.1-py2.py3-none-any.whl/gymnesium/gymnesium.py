import numpy as np
from cynes import *
from cynes import NES
from cynes.windowed import WindowedNES
import gymnasium as gym
from gymnasium.spaces import Box
from gymnasium.spaces import Discrete
from ._rom import ROM

# height in pixels of the NES screen
SCREEN_HEIGHT = 240
# width in pixels of the NES screen
SCREEN_WIDTH = 256

SCREEN_SHAPE_24_BIT = SCREEN_HEIGHT, SCREEN_WIDTH, 3

class NESRam:
    def __init__(self, nes):
        self.nes = nes

    def __getitem__(self, address):
        return self.nes[address]

    def __setitem__(self, address, value):
        self.nes[address] = value

class NESEnv(gym.Env):
    ''' NES Gymnasium Environment. '''

    def __init__(self, rom_path, headless=False):
        """
        Create a new NES environment.

        Args:
            rom_path (str): The path to the NES .rom file to be loaded.
            headless (bool): Optional - Define whether the environment should run in headless mode with no window, or not.

        Returns:
            None

        """
        # Create a ROM file from the ROM path
        rom = ROM(rom_path)
        
        # Check the ROM is valid
        if rom.prg_rom_size == 0: raise ValueError('ROM has no PRG-ROM banks.')
        if rom.has_trainer: raise ValueError('ROM has trainer. trainer is not supported.')
        if rom.is_pal: raise ValueError('ROM is PAL. PAL is not supported.')
        
        self._has_backup = False # Initially no state has been saved
        self.done = True # Setup a done flag

        self.headless = headless
        self.nes = NES(rom_path) if self.headless else WindowedNES(rom_path) # Instance the cynes emulator
        self._ram = NESRam(self.nes)

        # Define observation and action spaces
        self.observation_space = Box(low=0, high=255, shape=(240, 256, 3), dtype=np.uint8)
        self.action_space = Discrete(256)


    @property
    def ram(self):
        return self._ram
    
    def reset(self, seed=None, options=None):
        '''
        Reset the emulator to the last save, or to power on if no save is present.

        Args:
            seed (optional int):    The seed that is used to initialize the parent Gym environment's PRNG (np_random).
            
            options (optional dict): Additional information to specify how the environment is reset (optional)
        '''
        super().reset(seed=seed, options=options)

        # Call the before reset callback
        self._will_reset()

        # Reset the emulator
        if self._has_backup: self._restore()
        else: self.nes.reset()

        # Call the after reset callback
        self._did_reset()

        self.done = False
        obs = self.nes.step(frames=1)  # Capture an initial frame
        obs = np.array(obs, dtype=np.uint8)  # Ensure it's a valid numpy array
        info = {}
        return obs, info

    def step(self, action):
        raise NotImplementedError

    def _backup(self) -> None:
        """Backup the current emulator state."""
        self._backup_state = self.nes.save()
        self._has_backup = True

    def _restore(self) -> None:
        """Restore the emulator state from backup."""
        self.nes.load(self._backup_state)

    def _frame_advance(self, action):
        """
        Advance the emulator by one frame with the given action.

        Args:
            action (int): The action to perform (controller input).
        """
        # Set the controller inputs
        self.nes.controller = action

        # Advance the emulator by one frame
        frame = self.nes.step(frames=1)

        # Update the current frame (observation)
        self.screen = frame


